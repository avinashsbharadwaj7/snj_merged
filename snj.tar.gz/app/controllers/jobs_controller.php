<?php
class JobsController extends AppController {
    public $name = 'Jobs';
    public $helpers = array('Html', 'Form','Ajax','Javascript', 'DatePicker');
    public $components = array('Session');
	public $uses = array( 'Job'
	                     ,'Task'
                         ,'Node'
                         ,'Dropdown'
                         ,'NodeConflict'
	                     ,'Snjscopeofwork'
	                     ,'Vieworganization'
	                     ,'Viewworklocation'
	                     ,'Viewcustomer'
	                     ,'Viewtechnology'
	                     ,'Viewregion'
	                     ,'Viewworkdaytime'
	                     ,'Viewrequesttype'
	                     ,'Mop'
	                     ,'Market'
						 ,'Resource'
						 ,'User'
						 ,'Groupid','DistributionList'
	                    );
    
	                    
    public function beforeFilter()
    {
        $this->set('pmgroupid', $this->Groupid->getGroupID(Groupid::PM_GROUP));
        $this->set('lmgroupid', $this->Groupid->getGroupID(Groupid::LM_GROUP));
        $this->set('enggroupid', $this->Groupid->getGroupID(Groupid::ENG_GROUP));
    }
    
    public function index() {
        $this->set('jobs', $this->Job->find('all'));
    }
	

    public function view($id = null) 
	{
		$res = $this->Job->find('all', array ('conditions' => array ('job_id' => $id), 'order' => 'rev_no DESC', 'limit' => '1'));
		
		$job['Job'] = $res[0]['Job'];
		//debug ($job);
				
		$job['Job']['Organization'] = $this->Vieworganization->getOrgName($job['Job']['Organization'] );
		$job['Job']['Scope_of_work'] = $this->Snjscopeofwork->getSoWName($job['Job']['Scope_of_work']);
		
		$job['Job']['Work_Location'] = $this->Viewworklocation->getWorkLocationDescription($job['Job']['Work_Location']);
		$job['Job']['customer'] = $this->Viewcustomer->getCustomerName ($job['Job']['customer']);
		
		$data = $this->Job->query("SELECT * FROM tasks as Task WHERE job_id = '".$id."' AND rev_no = (SELECT max(rev_no) FROM tasks WHERE job_id = '".$id."')");	
		//$nodeData = $this->Node->query (""SELECT * FROM nodes as Node WHERE job_id = '".$id."' AND rev_no = (SELECT max(rev_no) FROM nodes WHERE job_id = '".$id."')");
		$nodeData = $this->Node->find('all', array ('conditions' => array ('job_id' => $id)));
		$resourceData = $this->Resource->find('all', array('conditions' => array ('job_id' => $id, 'rev_no' => 1, 'nullified <>' => 1)));
				
	    $mopLinkRes = $this->Job->query("SELECT mop_link, mop_name FROM mops WHERE mops.mop_id = '".$job['Job']['mop_link']."'");
		if (sizeof($mopLinkRes) != 0)
		{
			$job['Job']['mop_link'] = $mopLinkRes[0]['mops']['mop_link'];
			$job['Job']['mop_name'] = $mopLinkRes[0]['mops']['mop_name'];
			$this->set("flag", 0);
		}
		
		else
		{
			$this->set("flag", 1);
		}
		
		$job['Job']['Technology'] = $this->Viewtechnology->getTechnologyDescription($job['Job']['Technology']);
				
		$this->set('job', $job );
		$this->set ('tasks', $data);
		$this->set ('nodes', $nodeData);
		$this->set ('resources', $resourceData);
		
    }
	private function __convertTime ($cakeTime)
	{
		if (!strcmp($cakeTime['meridian'],'am'))
		{
			$resTime = $cakeTime['hour'] + 12;
			
			
			if ($resTime == 24)
			{
				$resTime = '00:'.$cakeTime['min'].":00";
			}
			
			else 
			{
				$resTime = $resTime - 12;
				if ($resTime < 10)
				{
					$resTime = "0".$resTime.":".$cakeTime['min'].":00";
				}
				else
				{
					$resTime = $resTime.":".$cakeTime['min'].":00";
				}
			}
								
		}
		else if (!strcmp ($cakeTime['meridian'], 'pm'))
		{
		
			$resTime = $cakeTime['hour'];
			if ( $cakeTime['hour'] == 12)
			{
				$resTime = $cakeTime['hour'];
				//$resTime = $resTime + 12;
				$resTime = $resTime.":".$cakeTime['min'].":00";
			}
			
			else
			{
				$resTime = $resTime + 12;
				$resTime = $resTime.":".$cakeTime['min'].":00";
			}
		}
		
		else
		{				
			$resTime = $cakeTime['hour'].":".$cakeTime['min'].":00";
		}
		
		//debug ($resTime);
		//debug ($cakeTime);
		return $resTime;
	}
	
	private function __validate ()
	{
		$flag = false;
				
		date_default_timezone_set('America/Chicago');
		
		if ($this->data['Task']['start_date'] == '')
		{
			$this->Session->setFlash('ENTER START DATE');
			$flag = true;
		}
	
		if ($this->data['Task']['end_date'] == '')
		{
			$this->Session->setFlash('ENTER END DATE');
			$flag = true;
		}
		
		$start_time = $this->__convertTime ($this->data['Task']['start_time']);
		//debug ($this->data['Task']['start_time']);
		//debug ($start_time);
		
		if ($start_time == '::00')
		{
			$this->Session->setFlash('ENTER START TIME');
			$flag = true;
		}
		
		$end_time = $this->__convertTime ($this->data['Task']['end_time']);
		
		if ($end_time == '::00')
		{
			$this->Session->setFlash('ENTER END TIME');
			$flag = true;
		}
		
		$dateTime = $this->data['Task']['start_date'].' '.$start_time;
		//debug (date( 'Y-m-d H:i:s'));
		//debug ($dateTime);
		
		if ($dateTime < date( 'Y-m-d H:i:s'))
		{
			$this->Session->setFlash('Enter a start date and time which is later than todays date');
			$flag = true;
		}
		
		if ($this->data['Task']['start_date'] > $this->data['Task']['end_date'])
		{
			$this->Session->setFlash('Enter a end date which is greater than the start date');
			$flag = true;
		}
		
		if ($end_time < $start_time)
		{
			if ($this->data['Task']['end_date'] <= $this->data['Task']['start_date'])
			{
				$this->Session->setFlash('Enter an end time which is after the start time');
				$flag = true;
			}
		}

		if ($this->data['Node']['concerned_node'] == '')
		{
			$this->Session->setFlash('Enter a set of concerned nodes');
			$flag = true;					
		}
		
		return $flag;
	}

	public function _isResourceNullified($oldData = null, $newData = null)
	{
		if ($oldData['start_date'] != $newData['start_date'])
		{
			return false;
		}
		
		else if ($oldData['end_date'] != $newData['end_date'])
		{
			return false;
		}
		
		else if ($oldData['start_time'] != $newData['start_time'])
		{
			return false;
		}
		
		else if ($oldData['end_time'] != $newData['end_time'])
		{
			return false;
		}
		
		else if ($oldData['no_of_eng_needed'] != $newData['no_of_eng_needed'])
		{
			return false;
		}
		
		else
		{
			return true;
		}
	}
	
    public function add() 
	{
	    ini_set('error_log', '/tmp/snj.log');
	    
	    $errorsFound = false;
	    
		$orgs = array("--Select--") + $this->Vieworganization->getOrgs();
		$this->set("orgs", $orgs);
		    
		$workLocations = array("--Select--") + $this->Viewworklocation->getWorkLocations();
		$this->set("workLocations", $workLocations);
		    
		$customers = array("--Select--") + $this->Viewcustomer->getCustomers();
		$this->set("customers", $customers);
		    
		$technologies = array("--Select--") + $this->Viewtechnology->getTechnologies();
		$this->set("technologies", $technologies);
		
		$regions = $this->Viewregion->getRegions();
		$this->set("regions", $regions);
		    
		$workDayTimes = $this->Viewworkdaytime->getWorkDayTimes();
		$this->set("workDayTimes", $workDayTimes);
		
		$requestTypes = array("--Select--") + $this->Viewrequesttype->getRequestTypes();
		$this->set("requestTypes", $requestTypes);
		    
		$markets = array("--Select--") + $this->Market->getMarkets();
		$this->set("markets", $markets);
		    
		$sows = array("--Select--") + $this->Snjscopeofwork->getSoooWs($this->data['Job']['Organization']);
		$this->set("sows", $sows);
		    
		$mopNames = array("--Select--") + $this->Mop->getMopNamesSow($this->data['Job']['Scope_of_work']);
		$this->set("mopNames", $mopNames);
		    
		$dropdown_values = $this->Dropdown->find('all',array('order'=>array('weight ASC','value'),'conditions'=>array('module_id'=>7)));
		$this->set('dropdown_values',$dropdown_values);
		
		
		//debug ($this->data);
		
        if (!empty ($this->data)) 
		{
		    //debug ($this->data);
			
			$res = $this->Job->find('first', array (
				'fields' => 'max(job_id)'
			));			
			
			$jobid = $res[0]['max(job_id)'];
			$jobid++;
			
			$task_id = $this->Job->getMaxTaskId($jobid) + 1;
			$this->data['Job']['date_created'] = $mysqldate = date( 'Y-m-d H:i:s');
			$this->data['Job']['job_id'] = $jobid;
			
			//$this->data['Task']['ticket_conflict_status'] = 0;			
			$this->data['Task']['job_id'] = $jobid;
			$this->data['Task']['task_id'] = $task_id;
			$this->data['Task']['rev_no'] = 0;
			$this->data['Job']['rev_no'] = 0;
			
			$this->data['Task']['job_rev_no'] = 0;
			
			$this->data['Node']['job_rev'] = 0;
			$this->data['Node']['task_rev'] = 0;
			
			//debug ($this->data);
			if ($this->__validate())
			{
				//debug ('IN HERE');
				return;
			}
			
			$parent_names = array ();
			
			$tempConcernedNode = $this->data['Node']['concerned_node'];
			$node_names = $this->data['Node']['concerned_node'];
			//debug($node_names);
			
			$nodes = preg_split('@[\W]+@', $node_names, -1, PREG_SPLIT_NO_EMPTY);
			//debug($nodes);
			
			$cid = 1;
			
			$tempParent = "";
			
			if ($this->Job->save($this->data))
			{				  
				$errorsFound = false;
			}
			
			else
			{
				//debug ($tempConcernedNode);
				$this->data['Job']['concerned_node'] = $tempConcernedNode;
				$this->Session->setFlash("Job Data cannot be saved");
				$errorsFound = true;
				return;
			}
			
			foreach ($nodes as $node)
			{
				/* TODO: do we need this?
				if ($task_id != sizeof($nodes))
				{
					$node = substr($node, 0, -1);
				}
				*/
				
				$this->data['Task']['parallel_activity'] = $this->data['Job']['Parallely_Running_Activity'];
				$this->data['Task']['node_name'] = $node;
				$this->data['Node']['concerned_node'] = $node;
				$this->data['Node']['task_id'] = $task_id;
				$this->data['Task']['task_id'] = $task_id;
				
				$count = 0;
				$parent_names[0] = $node;
				
				$parent_name = $parent_names[0];
				
				$nodeType = $this->Node->getNodeType($node);					
									
													
				if ("" == $nodeType)
				{
					$msg = $msg.$node.", ";

					$msg = "INVALID NODE: ";
					$errorsFound = true;
					//break;
				}
				
				
				else
				{
					while (sizeof($parent_name))
					{	
						$size = sizeof($parent_name);
						//debug ($size);
						$query = "SELECT name, type FROM target WHERE id = (SELECT parent_id FROM target_parent WHERE node_id = (SELECT id FROM target WHERE name = '". $parent_names[$count]. "'))";
						
						$parent_name = $this->Job->query($query);	
						
						
						//debug ($parent_name);
						if (sizeof($parent_name) != 0 )
						{
							if ($count == 1)
							{
								//$this->Session->setFlash('IN HERE');
								$this->Node->query ("INSERT INTO nodes (job_rev, task_rev, job_id, task_id, concerned_node, target_node, adjacent_nodes, node_type) VALUES ('0', '1', '".$jobid."', '".$task_id."', '".$parent_name[0]['target']['name']."', '".$this->data['Node']['target_node'.$count]."', '".$this->data['Node']['adjacent_nodes'.$count]."', '" .$parent_name [0]['target']['type']. "')");
								$count++;
								$parent_names[$count] = $parent_name[0]['target']['name'];
							}
							
							else
							{
								$this->Node->query ("INSERT INTO nodes (job_rev, task_rev, job_id, task_id, concerned_node, target_node, adjacent_nodes, node_type) VALUES ('0', '1', '".$jobid."', '".$task_id."', '".$parent_name[0]['target']['name']."', '".$this->data['Node']['target_node']."', '".$this->data['Node']['adjacent_nodes']."', '" .$parent_name [0]['target']['type']. "')");
								$count++;
								$parent_names[$count] = $parent_name[0]['target']['name'];
							}
						}
					
						else 
						{								
							//debug ($query);
							$msg = "PARENT FOR ".$node." NOT FOUND";
							$errorsFound = true;
							
							if ($parent_names[$count] == "JAGUAR" || $parent_names[$count] == "ATTOSS34")
							{
								$errorsFound = false;
							}
						}
					}
					
					//debug($tempParent);
					//$errorsFound = true;
					if ($this->data['Job']['node_Reparenting'] == true)
					{
						if ($parent_names[1] != $tempParent && $tempParent != "")
						{
							//debug($parent_names);
							//debug ($tempParent);
							$msg = "PARENT NODE INFORMATION MISMATCH";
							$nodeMismatch = true;
							$errorsFound = true;	
						}						
					}
					
					$tempParent = $parent_names[1];	
					
				}
				
				
				if ($errorsFound == false)
				{
					$this->Job->query ("INSERT INTO nodes (job_rev, task_rev, job_id, task_id, concerned_node, node_type) VALUES ('0', '1', '".$jobid."', '".$task_id."', '".$node."', '" . $nodeType. "')");
					
					$this->Task->create();
					if ($this->Task->save($this->data))
					{
						$task_id++;
					}
				}
			
				else
				{
					$this->data['Job']['concerned_node'] = $tempConcernedNode;
					$this->Session->setFlash($msg);
					$errorsFound = true;
					break;
				}
			}

			if ($errorsFound == true)
			{
				$this->data['Job']['concerned_node'] = $tempConcernedNode;
				$this->Session->setFlash($msg);
				$errorsFound = true;
			}
			
			else
			{
				$this->redirect('/jobs/crp/'.$jobid);
				//debug ($jobid);
				//$this->SendemailSL($jobid, 'A');
				
			}
                        
			if($errorsFound == true)
			{
				//set organization
				$this->set('JobOrganization', $this->data['Job']['Organization']);
				//JobTechnology
				$this->set('JobTechnology', $this->data['Job']['Technology']);
				//scope_of_work
				$this->set('scope_of_work', $this->data['Job']['Scope_of_work']);
			}
        }
		
		
    }
	
	function edit($id = null) 
	{
		ini_set('error_log', '/tmp/snj.log');
	    
		$concernedNodes = "";
                $errorsFound = false;
	    
		$orgs = array("--Select--") + $this->Vieworganization->getOrgs();
		$this->set("orgs", $orgs);
		    
		$workLocations = array("--Select--") + $this->Viewworklocation->getWorkLocations();
		$this->set("workLocations", $workLocations);
		    
		$customers = array("--Select--") + $this->Viewcustomer->getCustomers();
		$this->set("customers", $customers);
		    
		$technologies = array("--Select--") + $this->Viewtechnology->getTechnologies();
		$this->set("technologies", $technologies);
		
		$regions = $this->Viewregion->getRegions();
		$this->set("regions", $regions);
		    
		$workDayTimes=$this->Viewworkdaytime->getWorkDayTimes();
		$this->set("workDayTimes", $workDayTimes);
		
		$requestTypes = array("--Select--") + $this->Viewrequesttype->getRequestTypes();
		$this->set("requestTypes", $requestTypes);
		    
		$markets = array("--Select--") + $this->Market->getMarkets();
		$this->set("markets", $markets);
		    
		$sows = array("--Select--") + $this->Snjscopeofwork->getSoooWs();
		$this->set("sows", $sows);
		    
		$mopNames = array("--Select--") + $this->Mop->getMopNames();
		$this->set("mopNames", $mopNames);
		    
		$dropdown_values = $this->Dropdown->find('all',array('order'=>array('weight ASC','value'),'conditions'=>array('module_id'=>7)));
		$this->set('dropdown_values',$dropdown_values);
		
		
		if (empty($this->data))		
		{
			$resJob = $this->Job->query("SELECT * FROM jobs as Job WHERE job_id = '".$id."' AND rev_no = (SELECT max(rev_no) FROM jobs WHERE job_id = '".$id."')");
			$resTask = $this->Task->query("SELECT * FROM tasks as Task WHERE job_id = '".$id."' AND rev_no = (SELECT max(rev_no) FROM tasks WHERE job_id = '".$id."')");
			$resNode = $this->Node->find('all', array ('conditions' => array ('job_id'=> $id)));
                        
                        
			$this->set('mstart_time',$resTask[0]['Task']['maintenance_window_start_time']);
			$this->set('mend_time',$resTask[0]['Task']['maintenance_window_end_time']);
			$this->set('mstart_date',$resTask[0]['Task']['maintenance_window_start_date']);
			$this->set('mend_date',$resTask[0]['Task']['maintenance_window_end_date']);
			
			//debug ($resTask);
			
			array_shift($resJob[sizeof($resJob) - 1]['Job']);
			$this->data['Job'] = $resJob[sizeof($resJob) - 1]['Job'];
			
			array_shift ($resTask[sizeof($resTask) - 1 ]['Task']);

			$this->data['Task']= $resTask[sizeof($resTask) - 1]['Task'];
			
			$concerendNode = "";
			//debug ($resTask);
			foreach ($resTask as $task)
			{
				$concerendNode = $concerendNode."\n".$task['Task']['node_name'];
			}
			
			$this->set('concernedNodes', $concerendNode);
			//debug ($this->data);
			
            $this->set('Organization',$this->data['Job']['Organization']);
            $this->set('mop_link_id',$this->data['Job']['mop_link']);

		} 
		
		else 
		{
		
			if ($this->__validate())
			{
				$this->redirect(array ('controller' => 'jobs', 'action' => 'edit', $this->data['Job']['job_id']));
			}
			
			$resJob = $this->Job->query("SELECT * FROM jobs as Job WHERE job_id = '".$id."' AND rev_no = (SELECT max(rev_no) FROM jobs WHERE job_id = '".$id."')");
			$resTask = $this->Task->query("SELECT * FROM tasks as Task WHERE job_id = '".$id."' AND rev_no = (SELECT max(rev_no) FROM tasks WHERE job_id = '".$id."')");
			
			$oldData['no_of_engineers'] = $resJob['no_of_engineers'];
			$oldData['start_date'] = $resTask['start_date'];
			$oldData['end_date'] = $resTask['end_date'];
			$oldData['start_time'] = $resTask['start_time'];
			$oldData['end_time'] = $resTask['end_time'];
			
			$newData['no_of_engineers'] = $this->data['Job']['no_of_engineers'];
			$newData['start_date'] = $this->data['Task']['start_date'];
			$newData['end_date'] = $this->data['Task']['end_date'];
			$newData['start_time'] = $this->data['Task']['start_time'];
			$newData['end_time'] = $this->data['Task']['end_time'];
			
			
			//Function to check if any of the resource nullification fields have changed.
			if (!($this->_isResourceNullified($oldData, $newData)))
			{
				//debug ("IN HERE");
				$this->Job->query ("UPDATE resources SET nullified = 1 WHERE job_id = '".$this->data['Job']['job_id']."'"); 
			}
			//debug ($this->data);
			
			$nodes = explode ("\n", $this->data['Node']['concerned_node']);
			$this->data['Job']['modification_timestamp'] = $mysqldate = date( 'Y-m-d H:i:s');
			$this->data['Task']['modifier_timestamp'] = $mysqldate = date( 'Y-m-d H:i:s');
			
			//debug ($this->data);
			
			$rev_no = $this->data['Job']['rev_no'];
			
			$this->data['Job']['rev_no'] = $rev_no + 1;

			//debug ($this->Job->id);
			$this->Job->create();
			if($this->Job->save($this->data)) 
			{
				$countTasks = $this->Task->getCountTasks($this->data['Job']['job_id']);
				$count = 1;
				
				//debug ($countTasks);
				while ($count <= $countTasks)
				{
					//debug ("IN HERE");
				
					$this->data['Task']['rev_no'] = $rev_no + 1;
					$this->data['Task']['task_id'] = $count;
					$this->data['Task']['job_id'] = $this->data['Job']['job_id'];
					$this->data['Task']['node_name'] = $nodes[$count - 1];
					
					//debug ($this->data['Task']);
					
					$this->Task->create();
					if (!($this->Task->save($this->data)))
					{
						//debug ("IN TASK HERE");
						$this->Session->setFlash('Your post can not be updated');
						break;
					}
					//$this->SendemailSL($this->data['Job']['job_id'], 'E');
					$count ++;
				}
				
				$this->Session->setFlash('Your post has been updated.');
			} 
			
			else 
			{
				$this->Session->setFlash('Unable to update your post.');
			}
			
            $this->set('Organization',$this->data['Job']['Organization']);
            $this->set('mop_link_id',$this->data['Job']['mop_link']);
			$this->redirect(array ('controller' => 'Jobs', 'action' => 'view', $this->data['Job']['job_id']));
		}	
	}
	
	function search ()
	{
		$errorsFound = false;
	    
		$orgs = array("--Select--") + $this->Vieworganization->getOrgs();
		$this->set("orgs", $orgs);
		    
		$workLocations = array("--Select--") + $this->Viewworklocation->getWorkLocations();
		$this->set("workLocations", $workLocations);
		    
		$customers = array("--Select--") + $this->Viewcustomer->getCustomers();
		$this->set("customers", $customers);
		    
		$technologies = array("--Select--") + $this->Viewtechnology->getTechnologies();
		$this->set("technologies", $technologies);
		
		$regions = array("--Select--") + $this->Viewregion->getRegions();
		$this->set("regions", $regions);
		    
		$workDayTimes = array("--Select--") + $this->Viewworkdaytime->getWorkDayTimes();
		$this->set("workDayTimes", $workDayTimes);
		
		$requestTypes = array("--Select--") + $this->Viewrequesttype->getRequestTypes();
		$this->set("requestTypes", $requestTypes);
		    
		$markets = array("--Select--") + $this->Market->getMarkets();
		$this->set("markets", $markets);
		    
		$sows = array("--Select--") + $this->Snjscopeofwork->getSoooWs();
		$this->set("sows", $sows);
		    
		$mopNames = array("--Select--") + $this->Mop->getMopNames();
		$this->set("mopNames", $mopNames);
		    
		$dropdown_values = $this->Dropdown->find('all',array('order'=>array('weight ASC','value'),'conditions'=>array('module_id'=>7)));
		$this->set('dropdown_values',$dropdown_values);
		
				
		
        $groupId = Authsome::get ('user_group_id');
            
		if (!empty ($this->data))
		{				
			// debug ($this->data);
			
			$conditions = "";
			
			if ($this->data['Job']['job_id'] != "")
			{
				$conditions = $conditions."AND job_id = '".$this->data['Job']['job_id']."'";
			}
			
			if ($this->data['Job']['Signum'] != "")
			{
				$conditions = $conditions."AND signum = '".$this->data['Job']['Signum']."'";
			}
			
			if ($this->data['Job']['Name'] != "")
			{
				$conditions = $conditions."AND Name = '".$this->data['Job']['Name']."'";
			}
			
			if ($this->data['Job']['Organization'] != 0)
			{
			    $conditions = $conditions." AND Organization = '".$this->data['Job']['Organization']."'";
			}
			
			if ($this->data['Job']['customer'] != 0)
			{
			    $conditions  = $conditions." AND customer = '".$this->data['Job']['customer']."'";
			}
			
			if ($this->data['Job']['Region'] != 0)
			{
			    $conditions = $conditions." AND Region = '".$this->data['Job']['Region'];
			}
			
			if ($this->data['Job']['Work_Location'] != 0)
			{
			   $conditions = $conditions." AND Work_Location = '".$this->data ['Job']['Work_Location'];
			}
			
			if ($this->data['Job']['Network_Number'] != "")
			{
			   $conditions = $conditions." AND Network_Number = '".$this->data ['Job']['Network_Number'];
			}
			
			if ($this->data['Job']['Technology'] != 0)
			{
			   $conditions = $conditions." AND Technology = '".$this->data ['Job']['Technology'];
			}
			
			if ($this->data['Job']['Market'] != 0)
			{
				$conditions = $conditions." AND Market = '".$this->data['Job']['Market'];
			}
			
			if ($this->data['Job']['scope_of_work'] != 0)
			{
				$conditions = $conditions." AND Scope_of_work = '".$this->data['Job']['scope_of_work'];
			}
			
			if ($this->data['Job']['Work_day_time'] != 0)
			{
				$conditions = $conditions." AND Work_day_time = '".$this->data['Job']['Work_day_time'];
			}
			
			$search_results = $this->Job->find('all',array("recursive"=>1, 'conditions' => $conditions));
			
			$this->set('search_results', $search_results);
			
		    $this->render('search_results');
                
		}
	}

	function getsearchresults ()
	{
	    $this->layout='ajax';
	    $this->autoLayout = false;
	    $this->autoRender = false;
	    $this->header('Content-Type: application/json');
		$taskConditions = "";
	    
		if (!empty ($this->data))
		{			
			
			//debug ($this->data);
			
			$conditions = "";
			
			if ($this->data['Job']['job_id'] != "")
			{
				$conditions = $conditions." AND Job.job_id = '".$this->data['Job']['job_id']."'";
			}
			
			if ($this->data['Job']['Signum'] != "")
			{
				$conditions = $conditions." AND Job.signum = '".$this->data['Job']['Signum']."'";
			}
			
			if ($this->data['Job']['Name'] != "")
			{
				$conditions = $conditions." AND Job.Name = '".$this->data['Job']['Name']."'";
			}
			
			if ($this->data['Job']['Organization'] != 0)
			{
			    $conditions = $conditions." AND Job.Organization = '".$this->data['Job']['Organization']."'";
			}
			
			if ($this->data['Job']['customer'] != 0)
			{
			    $conditions  = $conditions." AND Job.customer = '".$this->data['Job']['customer']."'";
			}
			
			if ($this->data['Job']['Region'] != 0)
			{
			    $conditions = $conditions." AND Job.Region = '".$this->data['Job']['Region']."'";
			}
			
			if ($this->data['Job']['Work_Location'] != 0)
			{
			   $conditions = $conditions." AND Job.Work_Location = '".$this->data ['Job']['Work_Location']."'";
			}
			
			if ($this->data['Job']['Network_Number'] != "")
			{
			   $conditions = $conditions." AND Job.Network_Number = '".$this->data ['Job']['Network_Number']."'";
			}
			
			if ($this->data['Job']['Technology'] != 0)
			{
			   $conditions = $conditions." AND Job.Technology = '".$this->data ['Job']['Technology']."'";
			}
			
			if ($this->data['Job']['Market'] != 0)
			{
				$conditions = $conditions." AND Job.Market = '".$this->data['Job']['Market']."'";
			}
			
			if ($this->data['Job']['scope_of_work'] != 0)
			{
				$conditions = $conditions." AND Job.Scope_of_work = '".$this->data['Job']['scope_of_work']."'";
			}
			
			if ($this->data['Job']['Work_day_time'] != 0)
			{
				$conditions = $conditions." AND Job.Work_day_time = '".$this->data['Job']['Work_day_time']."'";
			}
			
			if ( $this->data['Job']['Creation Date/Time'] == 1)
			{
				if ($this->data['Job']['Search Type'] ==  "daterange")
				{
					$conditions = $conditions." AND Job.date_created >= '" . $this->data['Job']['date_start'] . " 00:00:00' AND Job.date_created <= '" . $this->data['Job']['date_end'] . " 00:00:00'";
				}
				
				if  ($this->data['Job']['Search Type'] ==  "quarter")
				{
					if ($this->data['Job']['Quarter'] ==  1)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2012-01-01 00:00:00' AND '2012-04-01 00:00:00'";
					}
					
					if ($this->data['Job']['Quarter'] ==  2)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2012-04-01 00:00:00' AND '2012-07-01 00:00:00'";
					}
					
					if ($this->data['Job']['Quarter'] ==  3)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2012-08-01 00:00:00' AND '2012-10-01 00:00:00'";
					}
					
					if ($this->data['Job']['Quarter'] ==  4)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2012-10-01 00:00:00' AND '2013-01-01 00:00:00'";
					}
				}	
				
				if ($this->data['Job']['Search Type'] ==  "year")
				{
					if ($this->data['Job']['Year'] == 2009)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2009-01-01 00:00:00' AND '2010-01-01 00:00:00'";
					}
					
					if ($this->data['Job']['Year'] == 2010)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2010-01-01 00:00:00' AND '2011-01-01 00:00:00'";
					}
					
					if ($this->data['Job']['Year'] == 2011)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2011-01-01 00:00:00' AND '2012-01-01 00:00:00'";
					}
					
					if ($this->data['Job']['Year'] == 2012)
					{
						$conditions = $conditions." AND Job.date_created BETWEEN '2012-01-01 00:00:00' AND '2013-01-01 00:00:00'";
					}
				}
			}
			
			if ($this->data['Job']['Job Start Date/Time'] == 1)
			{
				if ($this->data['Job']['Search Type'] ==  "daterange")
				{
					$taskConditions = "  start_date BETWEEN '" . $this->data['Job']['date_start'] ."' AND '". $this->data['Job']['date_end'] . "'";
				}
				
				
				if  ($this->data['Job']['Search Type'] ==  "quarter")
				{
					if ($this->data['Job']['Quarter'] ==  1)
					{
						$taskConditions = " date_created BETWEEN '2012-01-01 00:00:00' AND '2012-04-01 00:00:00'";
					}
					
					if ($this->data['Job']['Quarter'] ==  2)
					{
						$taskConditions = "  date_created BETWEEN '2012-04-01 00:00:00' AND '2012-07-01 00:00:00'";
					}
					
					if ($this->data['Job']['Quarter'] ==  3)
					{
						$taskConditions = "   date_created BETWEEN '2012-08-01 00:00:00' AND '2012-10-01 00:00:00'";
					}
					
					if ($this->data['Job']['Quarter'] ==  4)
					{
						$taskConditions = "   date_created BETWEEN '2012-10-01 00:00:00' AND '2013-01-01 00:00:00'";
					}
				}
				
				if ($this->data['Job']['Search Type'] ==  "year")
				{
					if ($this->data['Job']['Year'] == 2009)
					{
						$taskConditions = "  date_created BETWEEN '2009-01-01 00:00:00' AND '2010-01-01 00:00:00'";
					}
					
					if ($this->data['Job']['Year'] == 2010)
					{
						$taskConditions = "  date_created BETWEEN '2010-01-01 00:00:00' AND '2011-01-01 00:00:00'";
					}
					
					if ($this->data['Job']['Year'] == 2011)
					{
						$taskConditions = " date_created BETWEEN '2011-01-01 00:00:00' AND '2012-01-01 00:00:00'";
					}
					
					if ($this->data['Job']['Year'] == 2012)
					{
						$taskConditions = " date_created BETWEEN '2012-01-01 00:00:00' AND '2013-01-01 00:00:00'";
					}
				} 
			}
			
			
			
			$conditions = substr($conditions, 5);
			
			//print_r ($taskConditions);
		    $json = $this->getmyticketsdata($conditions, null, $taskConditions);
		    echo json_encode($json);
			return;
			
		}
	}
	
	function search_results() {}
	
	function view_search($result_job)
	{
		$this->set('search_results', $result_job);
	}
	
	function __parsePreLaunch($id)
     {
         // echo "I am in PL  ";
          $dirPath = $this->Prupload->getUploadPath();
          $fileName = $this->Prupload->getFileName($id);
          
          App::import('Vendor', 'php-excel-reader/reader2');
          $data = new Spreadsheet_Excel_Reader();
          $data->setOutputEncoding('CP1251');
          $data->read("C:\\wamp\\www\\pqr\\".$fileName['Prupload']['name']);
           //debug($data);
            $rows = $data->sheets[0]['cells'];
            $map = $this->map();
            $i=0;
            $exceldata = array();
            foreach($rows as $row){
                if ($row[1] === "SITE")
                    continue;                
                $temp = null;
                $j=1;
                foreach($row as $column){                    
                    $temp[$map[$j++]] = $column;
                }
                $exceldata[$i] = $temp;
                $i++;
            }
            $this->__SaveDatapac($exceldata);                       
           
        }
        
    private function __SaveDatapac($exceldata){        
        App::import('model', 'prelaunchnds');
        $prelaunchnds = new prelaunchnd();
        Configure::write('debug', 0);
        foreach($exceldata as $record)
        {   
            $prelaunchnds->saveAll($record);        
        }    
    }
     function map(){
        return array(
            1 => 'site', 2 => 'utrancell',3 => 'rnc',4 => 'market',5 => 'oss',
            6 => 'sonarport',7 => 'utranengg', 8 => 'rfpm',9 => 'comments'
         );
    }
            
     
    function __parseMarkLaunch($id)
    {
         $dirPath = $this->Prupload->getUploadPath();
          $fileName = $this->Prupload->getFileName($id);
          App::import('Vendor', 'php-excel-reader/reader2');
            //$data = new Spreadsheet_Excel_Reader("C:/wamp/www/pqr".$fileName['Prupload']['name'], true);
            $data = new Spreadsheet_Excel_Reader('PreLaunch_NDS.xls',true);
            $data->setOutputEncoding('CP1251');
            //debug($data);
            $map = $this->map();
            $i=0;
            $exceldata = array();
            foreach($rows as $row){
                if ($row[1] === "SITE")
                    continue;                
                $temp = null;
                $j=1;
                foreach($row as $column){                    
                    $temp[$map[$j++]] = $column;
                }
                $exceldata[$i] = $temp;
                $i++;
            }
            $this->__SaveDatapac($exceldata);                       
    }
	
	public function crp($id = null)
	{
		$nodeconflict = $this->NodeConflict->find('count', array ('conditions' => array ('job_id' => $id)));
		$this->set('id', $id);
		
		
		if (empty($this->data))
		{
			if ($nodeconflict == 0)
			{	
			
				$job_id = $id;
				
				$this->set('flag', 1);
				
				$this->Job->query ("UPDATE jobs SET rev_no = 1, conflict_comments = '".$this->data['Job']['conflict_comments']."'"."WHERE job_id = '".$job_id."'");
				$this->Job->query ("UPDATE tasks SET rev_no = 1, job_rev_no = 1 WHERE job_id = '".$job_id."'");
				$this->Job->query ("UPDATE nodes SET job_rev = 1 WHERE job_id = '".$job_id."'");
				
				//debug ("UPDATE tasks SET ticket_conflict_status = 1 WHERE job_id = '".$job_id."'");
				
				$this->redirect ('view/'.$id);
			}
			
			else
			{
				$this->set('flag', 0);
				
				
				$conflicting_nodes = $this->NodeConflict->find('all', array('conditions' => array ('job_id' => $id), 'fields' => array ('DISTINCT conflicting_job_id', 'node_name', 'task_id')));
				
				$conflicting_information = $this->Job->find('all', array('conditions'=>array ('job_id'=>$conflicting_nodes[0]['NodeConflict']['conflicting_job_id']), 'fields' => array ('Name', 'Scope_of_work')));
				
				$this->set('sow', $this->Snjscopeofwork->getSoooWs());
				$this->set('conflicting_nodes', $conflicting_nodes);
				$this->set('conflicting_informations', $conflicting_information);
				
			}
		}
		
		else
		{
			$job_id = $this->data['Job']['id'];
			
			$flag = true;
			
			if ($this->data['Job']['conflict_comments'] == '')
			{
				$this->Session->setFlash ('PLEASE ENTER THE COMMENTS');
				$flag = false;
				$this->redirect ('crp/'.$job_id);
			}
			
			if ($flag)
			{
				$this->Job->query ("UPDATE jobs SET rev_no = 1, conflict_comments = '".$this->data['Job']['conflict_comments']."'"."WHERE job_id = '".$job_id."'");
				$this->Job->query ("UPDATE tasks SET rev_no = 1, job_rev_no = 1 WHERE job_id = '".$job_id."'");
				$this->Job->query ("UPDATE nodes SET job_rev = 1 WHERE job_id = '".$job_id."'");
				
				//debug ("UPDATE tasks SET ticket_conflict_status = 1 WHERE job_id = '".$job_id."'");
				$this->Job->query ("UPDATE tasks SET ticket_conflict_status = 1 WHERE job_id = '".$job_id."'");
				
				$this->redirect ('view/'.$job_id);
			}
		}
	}
	
        
        public function addsupport($jobid = null, $taskid = null)
        {
                 if (empty ($this->data))
                {
                    $this->set('jobid',$jobid);
                    $this->set('taskid',$taskid);
                    $job = $this->Job->find('all', array ('conditions' => array ('job_id' => $jobid)));
                    $task = $this->Task->find('all', array ('conditions' => array ('task_id' => $taskid, 'job_id' => $jobid)));
		
			$this->set ('task', $task);
			$this->set ('job', $job);
			
		 }
                else
                {
                    $supportSignums = preg_split('@[\W]+@', $this->data['Resource']['support_signums'], -1, PREG_SPLIT_NO_EMPTY);
                    foreach ($supportSignums as $supportSignum)
                    {
                            $this->Resource->query("INSERT INTO resources (job_id, task_id, user_signum, start_date, start_time, end_date, end_time, rev_no, nullified) VALUES ('".$jobid."', '".$taskid."', '".$supportSignum."', 1, 0)");
                    }
                    $this->redirect (array ('controller' => 'jobs', 'action' => 'mytickets'));
                }
        }
        
	public function viewengineer($jobid = null, $taskid = null) 
	{
		
		if (empty ($this->data))
		{
			
			$this->set('jobid',$jobid);
			$this->set('taskid',$taskid);
		
			$job = $this->Job->find('all', array ('conditions' => array ('job_id' => $jobid)));
			$task = $this->Task->find('all', array ('conditions' => array ('task_id' => $taskid, 'job_id' => $jobid)));
		
			$this->set ('task', $task);
			$this->set ('job', $job);
			
			$organization = $job[0]['Job']['Organization'];
			
			$this->set ('organization', $organization);
			
			$jobStatus = $task[0]['Task']['ticket_status'];
			
			$options = array('0'=>'New Ticket',
                                 '1' => 'Started');
								 
			if ($jobStatus == 1)
			{
				$options = array ('2' => 'Partialy Completed',
								  '3' => 'completed');
			}
			
			if ($jobStatus == 2)
			{
				$options = array ('4' => 'Restarted');
			}
			
			if ($jobStatus == 3)
			{
				$options = array ('3' => 'Completed');
			}
			
			if ($jobStatus == 4)
			{
				$options = array ('2' => 'Partialy Completed', '3' => 'Restarted');
			}
								 
			$this->set ('options' , $options);
			
			//$this->redirect ('viewengineer/'.$jobid.'/'.$taskid);
		}
		
		else
		{
			
			$organization = Authsome::get('organization');
			
			if ($organization == 'LDO NIC' && $this->data['Job']['organization'] == 3)
			{			
				if ($this->data['Job']['ticket_status'] == 1 || $this->data['Job']['ticket_status'] == 4)
				{
					debug ("IN HERE");
					$jobid = $this->data['Job']['job_id'];
					$taskid = $this->data['Job']['task_id'];
					
					$task = $this->Task->find('all', array ('conditions' => array ('job_id' => $jobid, 'task_id' => $taskid)));
					//debug ($task);
					
					$user_signum = $this->data['Job']['user_signum'];
					$resource_name = $this->data['Job']['resource_name'];
					
					$start_date = $task[0]['Task']['start_date'];
					$end_date = $task[sizeof($task) - 1]['Task']['end_date'];
					
					$start_time = $task[sizeof($task) - 1]['Task']['start_time'];
					$end_time = $task[sizeof($task) - 1]['Task']['end_time'];
					
					$designation = $this->User->getDesignation($user_signum);
					
					$this->Job->query("INSERT INTO resources (job_id, task_id, user_signum, start_date, start_time, end_date, end_time, resource_name, rev_no, nullified, availability, designation) VALUES ('".$jobid."', '".$taskid."', '".$user_signum."', '".$start_date."', '".$start_time."', '".$end_date."', '".$end_time."', '".$resource_name."', 1, 0, 100, '" .$designation."')");
					
					$supportSignums = preg_split('@[\W]+@', $this->data['Job']['support_signums'], -1, PREG_SPLIT_NO_EMPTY);
					
					foreach ($supportSignums as $supportSignum)
					{
						$this->Job->query("INSERT INTO resources (job_id, task_id, user_signum, start_date, start_time, end_date, end_time, rev_no, nullified) VALUES ('".$jobid."', '".$taskid."', '".$supportSignum."', 1, 0)");
					}
					
					
				}
			}
			
			$this->Job->query ("UPDATE tasks SET ticket_status = '".$this->data['Job']['ticket_status']."' WHERE job_id = '".$this->data['Job']['job_id']."' AND task_id = '".$this->data['Job']['task_id']."'");
			$this->redirect (array ('controller' => 'jobs', 'action' => 'mytickets'));
		}
		
	}
	
	public function support_signum($jobId = null, $taskId = null)
	{
		if (empty ($this->data))
		{
			$this->set ('taskId', $taskId);
			$this->set ('jobId', $jobId);
		}
		
		else
		{
			$supportSignums = preg_split('@[\W]+@', $this->data['Job']['support_signums'], -1, PREG_SPLIT_NO_EMPTY);
			$jobid = $this->data['Job']['job_id'];
			$taskid = $this->data['Job']['job_id'];
			foreach ($supportSignums as $supportSignum)
			{
				$this->Job->query("INSERT INTO resources (job_id, task_id, user_signum, rev_no, nullified) VALUES ('".$jobid."', '".$taskid."', '".$supportSignum."', 1, 0)");
			}
			
			$this->redirect (array ('controller' => 'jobs', 'action' => 'mytickets'));
		}
	}
	
	
	/*
	 * This action returns json data. So, no view.
	 */
	public function getmytickets()
	{
	    $this->layout='ajax';
	    $this->autoLayout = false;
	    $this->autoRender = false;
	    $this->header('Content-Type: application/json');
	    
		$groupId = Authsome::get ('user_group_id');
		$signum = Authsome::get ('username');
		$organization = Authsome::get ('organization');
		
		
		
		$orgId = $this->Vieworganization->getOrgId($organization);
		
		$ldoSelfAssign = false;

		$conditions = null;
		if ($groupId == $this->Groupid->getGroupID(Groupid::PM_GROUP))
		{
		    $conditions = "Signum = '". $signum. "'";
		}
		
		if ($groupId == $this->Groupid->getGroupID(Groupid::LM_GROUP))
		{
		    $conditions = "Organization = '". $orgId. "'";
		}
		
		if ($groupId == $this->Groupid->getGroupID(Groupid::ENG_GROUP))
		{
		   $conditions = "Resource.user_signum = '". $signum. "'";
		   if ($organization == 'LDO NIC')
		   {
		        $ldoSelfAssign = true;
		   }
		}
		
		$taskConditions = "";
	
		$json = $this->getmyticketsdata($conditions, $ldoSelfAssign, $taskConditions);
		echo json_encode($json);
		return;
	}
	
	public function getmyticketsdata($conditions, $ldoSelfAssign=false, $taskConditions = null )
	{
	    
		$groupId = Authsome::get ('user_group_id');
		
        $fieldMapping = array (
		     0 => array ('table' => 'Job', 'column' => 'job_id' , 'translate' => 'jobviewlink' )
		    ,1 => array ('table' => 'Job', 'column' => 'rev_no' , 'translate' => false )
		    ,2 => array ('table' => 'Job', 'column' => 'Signum' , 'translate' => false )
		    ,3 => array ('table' => 'Job', 'column' => 'Organization', 'translate' => 'organization' )
		    ,4 => array ('table' => 'Job', 'column' => 'Scope_of_work', 'translate' => 'scopeofwork' ) 
		    ,5 => array ('table' => 'Task', 'column' => null, 'translate' => 'conflictstatus' )
		    ,6 => array ('table' => 'Job', 'column' => 'no_of_eng_needed', 'translate' => 'resourcesassigned' )
		    ,7 => array ('table' => 'Task', 'column' => null, 'translate' => 'numchildtickets' )
		    ,8 => array ('table' => 'Job', 'column' => 'job_id', 'translate' => 'action' )
		);
		
		if ($groupId == $this->Groupid->getGroupID(Groupid::PM_GROUP))
		{
            $fieldMapping = array (
		     0 => array ('table' => 'Job', 'column' => 'job_id' , 'translate' => 'jobviewlink' )
		    ,1 => array ('table' => 'Job', 'column' => 'Organization', 'translate' => 'organization' )
		    ,2 => array ('table' => 'Job', 'column' => 'Scope_of_work', 'translate' => 'scopeofwork' ) 
		    ,3 => array ('table' => 'Job', 'column' => 'date_created', 'translate' => 'false' ) 
    		// ,3 => array ('table' => 'Task', 'column' => 'start_date' , 'translate' => 'jobstartdt' )
    		// ,4 => array ('table' => 'Task', 'column' => 'end_date' , 'translate' => 'jobenddt' )
		    ,4 => array ('table' => 'Task', 'column' => null, 'translate' => 'conflictstatus' )
		    ,5 => array ('table' => 'Job', 'column' => 'no_of_eng_needed', 'translate' => 'resourcesassigned' )
		    ,6 => array ('table' => 'Task', 'column' => null, 'translate' => 'numchildtickets' )
		    ,7 => array ('table' => 'Job', 'column' => 'job_id', 'translate' => 'action' )
            );
		}
		else  if ($groupId == $this->Groupid->getGroupID(Groupid::LM_GROUP))
	    {
            $fieldMapping = array (
		     0 => array ('table' => 'Job', 'column' => 'job_id' , 'translate' => 'jobviewlink' )
		    ,1 => array ('table' => 'Job', 'column' => 'Signum', 'translate' => false )
		    ,2 => array ('table' => 'Job', 'column' => 'Region', 'translate' => false ) 
		    ,3 => array ('table' => 'Job', 'column' => 'Scope_of_work', 'translate' => 'scopeofwork' ) 
		    ,4 => array ('table' => 'Job', 'column' => 'date_created', 'translate' => 'false' ) 
    		// ,3 => array ('table' => 'Task', 'column' => 'start_date' , 'translate' => 'jobstartdt' )
    		// ,4 => array ('table' => 'Task', 'column' => 'end_date' , 'translate' => 'jobenddt' )
		    ,5 => array ('table' => 'Task', 'column' => null, 'translate' => 'conflictstatus' )
		    ,6 => array ('table' => 'Job', 'column' => 'no_of_eng_needed', 'translate' => 'resourcesassigned' )
		    ,7 => array ('table' => 'Task', 'column' => null, 'translate' => 'numchildtickets' )
		    ,8 => array ('table' => 'Job', 'column' => 'job_id', 'translate' => 'action' )
            );
		}	
		
		$search_results = array();
		if ($groupId == $this->Groupid->getGroupID(Groupid::ENG_GROUP))
		{
  		   /*
		    * Engineer view: This is the mapping of HTML table column number to DB results indices [table][column]
		    */
		    $fieldMapping = array (
    		     0 => array ('table' => 'Job', 'column' => 'job_id' , 'translate' => 'ticketviewlink' )
    		    ,1 => array ('table' => 'Job', 'column' => null , 'translate' => 'lm' )
    		    ,2 => array ('table' => 'Task', 'column' => 'start_date' , 'translate' => 'resourcestartdt' )
    		    ,3 => array ('table' => 'Task', 'column' => 'end_date' , 'translate' => 'resourceenddt' )
    		    ,4 => array ('table' => 'Job', 'column' => 'Scope_of_work', 'translate' => 'scopeofwork' ) 
    		    ,5 => array ('table' => 'Job', 'column' => 'mop_link', 'translate' => 'moplink' )
    		    ,6 => array ('table' => 'Task', 'column' => 'ticket_status', 'translate' => 'taskstatus' )
    		);
		    $search_results = $this->Job->getTicketsEngineer($fieldMapping, $conditions, $ldoSelfAssign);
		}
		else
		{
			//echo $taskConditions;
		    $search_results = $this->Job->getTickets($fieldMapping, $conditions, $taskConditions);
		}
		//debug ($search_results);
		$json = array('aaData' => $search_results);
		return $json;
	}
	
	public function mytickets()
	{
		$groupId = Authsome::get ('user_group_id');
		if ($groupId == $this->Groupid->getGroupID(Groupid::ENG_GROUP))
		{
		     $this->render('myticketsengineer');
		}
		else if ($groupId == $this->Groupid->getGroupID(Groupid::PM_GROUP))
		{
		     $this->render('myticketspm');
		}
		else
		{
		     $this->render('myticketslm');
		}
	}
        
	public function sendEmailSL($id, $action)
    {
           
        $this->set('dataValues', $this->Job->read(null, $id));
        $this->data =  $this->Job->read(null, $id);
        
        $this->render = false;
        $dl = 'management';
        
        //get distribution list name based on organization, customer and region populated in the view
       $dl = $dl.";".$this->data['Job']['dlname'] ;
               
        //ask Preethi if we need to include other lists here..
         //get all the lists for this person
        //clarified with Preethi - we do not need to include DL emails here
       // $signum = Authsome::get ('username');
         //    $query = "select name from distribution_lists where id in 
           //     (select dl_id from email_lists where user_id=
             // (select id from users where username='".$signum."'))";
            
            //$res = $this->DistributionList->query($query);
        
       //  $distributionlists=$this->DistributionList->query($query);
          
         // foreach($distributionlists as $r)
        //{
          //  $dl = $dl.";".$r['distribution_lists']['name'];
         //}
         
       
        //get PM emails always
        $pmEmail = $this->Job->getPMEmail($id);
                 
        $actiondescr = "";
        switch($action)
        {
            case 'A': 
            {
                $actiondescr = "Add Job";
            }
            break;
                
            case 'E':
             {
                $actiondescr = "Edit Job";
             }
            break;
                
            case 'R':
             {
                $actiondescr = "Add Resources";
                $pmEmail = $pmEmail.$this->Job->getLMEmail($id);
                $pmEmail = $pmEmail.$this->Job->getResourcesEmails($id);
                
              }
            break;
        }
            
        
        $dl = $dl.";".$pmEmail;
                             
        $emails = "";             
        print_r("Emails:".$this->data['Job']['email_addresses']);
        if( $this->data['Job']['email_addresses']!= "") 
        {
            $emails = explode("\r\n", $this->data['Job']['email_addresses']);  
            $emails = implode("", $emails); 
            print_r($emails);
         }
        
        
        $subject = "Organization:" . $this->data['Job']['Organization'] . ", Customer:" . $this->data['Job']['customer'] . ", Region:" . $this->data['Job']['Region'] . ", Activity Type:" . $this->data['Job']['Scope_of_work'];
        $subject = "RNAM-PQR : SnJ " . $actiondescr . " - " . $subject;
        
        $this->sendEmail($dl, $emails, 'snj', $subject);
    }

    public function downloadpm() {       
        $this->view = 'Media';       
        $params = array( 
            'id' => 'userguidepm.zip', 
            'name' => 'userguide',              
            'download' => true,              
            'extension' => 'zip',  
            //// must be lower case          
            'path' => APP . 'files' . DS. 'snj' . DS  
            //    // don't forget terminal 'DS'            
            //            //     
            //   
            );  
            $this->set($params);    
    }
}

?>